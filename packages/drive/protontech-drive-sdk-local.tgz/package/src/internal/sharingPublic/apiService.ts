import { DriveAPIService, drivePaths } from '../apiService';

type PostTokenInfoRequest = Extract<
    drivePaths['/drive/v2/urls/{token}/bookmark']['post']['requestBody'],
    { content: object }
>['content']['application/json'];
type PostTokenInfoResponse =
    drivePaths['/drive/v2/urls/{token}/bookmark']['post']['responses']['200']['content']['application/json'];

type PostMalwareScanRequest = Extract<
    drivePaths['/drive/urls/{token}/security']['post']['requestBody'],
    { content: object }
>['content']['application/json'];
type PostMalwareScanResponse =
    drivePaths['/drive/urls/{token}/security']['post']['responses']['200']['content']['application/json'];

type PostReportShareAbuseRequest = Extract<
    drivePaths['/drive/report/share']['post']['requestBody'],
    { content: object }
>['content']['application/json'];
type PostReportShareAbuseResponse =
    drivePaths['/drive/report/share']['post']['responses']['200']['content']['application/json'];

/**
 * Provides API communication for actions on the public link.
 *
 * The service is responsible for transforming local objects to API payloads
 * and vice versa. It should not contain any business logic.
 */
export class SharingPublicAPIService {
    constructor(private apiService: DriveAPIService) {
        this.apiService = apiService;
    }

    async bookmarkPublicLink(bookmark: {
        token: string;
        encryptedUrlPassword: string;
        addressId: string;
        addressKeyId: string;
    }): Promise<void> {
        await this.apiService.post<PostTokenInfoRequest, PostTokenInfoResponse>(
            `drive/v2/urls/${bookmark.token}/bookmark`,
            {
                BookmarkShareURL: {
                    EncryptedUrlPassword: bookmark.encryptedUrlPassword,
                    AddressID: bookmark.addressId,
                    AddressKeyID: bookmark.addressKeyId,
                },
            },
        );
    }

    async malwareScan(token: string, hashes: string[]) {
        return this.apiService.post<PostMalwareScanRequest, PostMalwareScanResponse>(`drive/urls/${token}/security`, {
            Hashes: hashes,
        });
    }

    async reportAbuse(report: {
        sharePassphrase: string;
        shareId: string;
        abuseCategory: PostReportShareAbuseRequest['AbuseCategory'];
        bonaFide: true;
        reporterMessage?: string;
        reporterEmail?: string;
        shareUrl?: string;
        shareUrlPassword?: string;
        linkId?: string;
        revisionId?: string;
    }): Promise<void> {
        await this.apiService.post<PostReportShareAbuseRequest, PostReportShareAbuseResponse>(`drive/report/share`, {
            SharePassphrase: new TextEncoder().encode(report.sharePassphrase).toBase64(),
            ShareID: report.shareId,
            AbuseCategory: report.abuseCategory,
            BonaFide: report.bonaFide,
            ReporterMessage: report.reporterMessage ?? null,
            ReporterEmail: report.reporterEmail ?? null,
            ShareURL: report.shareUrl ?? null,
            ShareURLPassword: report.shareUrlPassword ?? null,
            LinkID: report.linkId ?? null,
            RevisionID: report.revisionId ?? null,
        });
    }
}
