import { c } from 'ttag';

import { ValidationError } from '../errors';
import { AbuseCategory, ReportShareAbuseSettings } from '../interface';

/**
 * Validates abuse report settings before sending them to the API.
 *
 * A reporter message is mandatory when reporting copyright infringement or
 * stolen data, as required by the abuse reporting backend.
 *
 * Shared by the direct share (`sharing`) and public link (`sharingPublic`)
 * reporting flows, which are independent modules but expose the same
 * `reportAbuse` contract.
 */
export function validateReportShareAbuseSettings(settings: ReportShareAbuseSettings): void {
    const requiresMessage =
        settings.abuseCategory === AbuseCategory.Copyright || settings.abuseCategory === AbuseCategory.StolenData;
    if (requiresMessage && !settings.reporterMessage) {
        throw new ValidationError(
            c('Error').t`A message is required when reporting copyright infringement or stolen data`,
        );
    }
}
