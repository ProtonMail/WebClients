import { c } from 'ttag';

import { AbortError, ProtonDriveError, RateLimitedError, ServerError } from '../../errors';
import { Logger, ProtonDriveHTTPClient, ProtonDriveTelemetry } from '../../interface';
import { VERSION } from '../../version';
import { isNetworkError } from '../errors';
import { SDKEvents } from '../sdkEvents';
import { waitSeconds } from '../wait';
import { HTTPErrorCode, isCodeOk, isCodeOkAsync } from './errorCodes';
import { apiErrorFactory } from './errors';

/**
 * The default timeout in milliseconds for all API requests (metadata).
 */
const DEFAULT_TIMEOUT_MS = 30000;

/**
 * The default timeout in milliseconds for all storage requests (file content).
 */
const DEFAULT_STORAGE_TIMEOUT_MS = 600_000;

/**
 * Maximum number of retry attempts for a timeout error.
 */
const MAX_TIMEOUT_ERROR_RETRY_ATTEMPTS = 3;

/**
 * Maximum number of retry attempts for a network error.
 */
const MAX_NETWORK_ERROR_RETRY_ATTEMPTS = 3;

/**
 * How many subsequent 429 errors are allowed before we stop further requests.
 */
const TOO_MANY_SUBSEQUENT_429_ERRORS = 50;

/**
 * For how long the API service should cool down after reaching the limit
 * of subsequent 429 errors.
 */
const TOO_MANY_SUBSEQUENT_429_ERRORS_TIMEOUT_IN_SECONDS = 60;

/**
 * How many subsequent 5xx errors are allowed before we stop further requests.
 */
const TOO_MANY_SUBSEQUENT_SERVER_ERRORS = 10;

/**
 * For how long the API service should cool down after reaching the limit
 * of subsequent 5xx errors.
 */
const TOO_MANY_SUBSEQUENT_SERVER_ERRORS_TIMEOUT_IN_SECONDS = 60;

/**
 * How many subsequent offline errors are allowed before we consider the client offline.
 */
const TOO_MANY_SUBSEQUENT_OFFLINE_ERRORS = 10;

/**
 * After how long to re-try after 5xx or timeout error.
 */
const SERVER_ERROR_RETRY_DELAY_SECONDS = 1;

/**
 * After how long to re-try after network error.
 */
const NETWORK_ERROR_RETRY_DELAY_SECONDS = 5;

/**
 * After how long to re-try after offline error.
 */
const OFFLINE_RETRY_DELAY_SECONDS = 5;

/**
 * After how long to re-try after 429 error without specified retry-after header.
 */
const DEFAULT_429_RETRY_DELAY_SECONDS = 10;

/**
 * After how long to re-try after general error.
 */
const GENERAL_RETRY_DELAY_SECONDS = 1;

/**
 * Provides API communication used withing the Drive SDK.
 *
 * The service is responsible for handling general headers, errors, conversion,
 * rate limiting, or basic re-tries.
 *
 * Error handling includes:
 *
 * * exception from HTTP client
 *   * retry on offline exc. (with delay from OFFLINE_RETRY_DELAY_SECONDS)
 *   * retry on transient network exc. (with delay from SERVER_ERROR_RETRY_DELAY_SECONDS)
 *   * retry ONCE on any exc. (with delay from GENERAL_RETRY_DELAY_SECONDS)
 * * HTTP status 429
 *   * retry (with delay from `retry-after` header or DEFAULT_429_RETRY_DELAY_SECONDS)
 *   * if too many subsequent 429s, stop further requests (defined in TOO_MANY_SUBSEQUENT_429_ERRORS)
 *   * when limit is reached, cool down for TOO_MANY_SUBSEQUENT_429_ERRORS_TIMEOUT_IN_SECONDS
 * * HTTP status 5xx
 *   * retry ONCE (with delay from SERVER_ERROR_RETRY_DELAY_SECONDS)
 *   * if too many subsequent 5xxs, stop further requests (defined in TOO_MANY_SUBSEQUENT_SERVER_ERRORS)
 *   * when limit is reached, cool down for TOO_MANY_SUBSEQUENT_SERVER_ERRORS_TIMEOUT_IN_SECONDS
 */
export class DriveAPIService {
    private subsequentTooManyRequestsCounter = 0;
    private lastTooManyRequestsErrorAt?: number;

    private subsequentServerErrorsCounter = 0;
    private lastServerErrorAt?: number;

    private subsequentOfflineErrorsCounter = 0;

    private logger: Logger;

    constructor(
        private telemetry: ProtonDriveTelemetry,
        private sdkEvents: SDKEvents,
        private httpClient: ProtonDriveHTTPClient,
        private baseUrl: string,
        private language: string,
    ) {
        this.logger = telemetry.getLogger('api');
        this.sdkEvents = sdkEvents;
        this.httpClient = httpClient;
        this.baseUrl = baseUrl;
        this.language = language;
        this.telemetry = telemetry;
    }

    async get<ResponsePayload>(url: string, signal?: AbortSignal): Promise<ResponsePayload> {
        return this.makeRequest(url, 'GET', undefined, signal);
    }

    async post<RequestPayload, ResponsePayload>(
        url: string,
        data?: RequestPayload,
        signal?: AbortSignal,
    ): Promise<ResponsePayload> {
        return this.makeRequest(url, 'POST', data, signal);
    }

    async postFormData<ResponsePayload>(
        url: string,
        formData: FormData,
        signal?: AbortSignal,
    ): Promise<ResponsePayload> {
        return this.makeRequest(url, 'POST', formData, signal);
    }

    async put<RequestPayload, ResponsePayload>(
        url: string,
        data: RequestPayload,
        signal?: AbortSignal,
    ): Promise<ResponsePayload> {
        return this.makeRequest(url, 'PUT', data, signal);
    }

    async delete<RequestPayload, ResponsePayload>(
        url: string,
        data?: RequestPayload,
        signal?: AbortSignal,
    ): Promise<ResponsePayload> {
        return this.makeRequest(url, 'DELETE', data, signal);
    }

    protected async makeRequest<RequestPayload, ResponsePayload>(
        url: string,
        method = 'GET',
        data?: RequestPayload,
        signal?: AbortSignal,
    ): Promise<ResponsePayload> {
        const isJson = !(data instanceof FormData);

        const headers = new Headers({
            Accept: 'application/vnd.protonmail.v1+json',
            Language: this.language,
            'x-pm-drive-sdk-version': `js@${VERSION}`,
        });
        // FormData must not get a manual Content-Type: the runtime sets it with the boundary.
        if (isJson) {
            headers.set('Content-Type', 'application/json');
        }

        const request = {
            url: `${this.baseUrl}/${url}`,
            method,
            headers,
            json: isJson && data ? data : undefined,
            body: !isJson && data ? data : undefined,
            timeoutMs: DEFAULT_TIMEOUT_MS,
            signal,
        };

        const response = await this.fetch(request, () => this.httpClient.fetchJson(request));

        try {
            const result = await response.json();

            if (!response.ok || !isCodeOk(result.Code)) {
                throw apiErrorFactory({ response, result });
            }
            if (isCodeOkAsync(result.Code)) {
                this.logger.info(`${request.method} ${request.url}: deferred action`);
            }
            return result as ResponsePayload;
        } catch (error: unknown) {
            if (error instanceof ProtonDriveError) {
                throw error;
            }
            throw apiErrorFactory({ response, error });
        }
    }

    async getBlockStream(baseUrl: string, token: string, signal?: AbortSignal): Promise<ReadableStream<Uint8Array>> {
        const response = await this.makeStorageRequest('GET', baseUrl, token, undefined, undefined, signal);
        if (!response.body) {
            throw new Error(c('Error').t`File download failed due to empty response`);
        }
        return response.body;
    }

    async postBlockStream(
        baseUrl: string,
        token: string,
        data: XMLHttpRequestBodyInit,
        onProgress?: (uploadedBytes: number) => void,
        signal?: AbortSignal,
    ): Promise<void> {
        await this.makeStorageRequest('POST', baseUrl, token, data, onProgress, signal);
    }

    protected async makeStorageRequest(
        method: 'GET' | 'POST',
        url: string,
        token: string,
        body?: XMLHttpRequestBodyInit,
        onProgress?: (uploadedBytes: number) => void,
        signal?: AbortSignal,
    ): Promise<Response> {
        const request = {
            url,
            method,
            headers: new Headers({
                'pm-storage-token': token,
                Language: this.language,
                'x-pm-drive-sdk-version': `js@${VERSION}`,
            }),
            body,
            onProgress,
            timeoutMs: DEFAULT_STORAGE_TIMEOUT_MS,
            signal,
        };

        const response = await this.fetch(request, () => this.httpClient.fetchBlob(request));

        if (response.status >= 400) {
            try {
                const result = await response.json();
                throw apiErrorFactory({ response, result });
            } catch (error: unknown) {
                if (error instanceof ProtonDriveError) {
                    throw error;
                }
                throw apiErrorFactory({ response, error });
            }
        }
        return response;
    }

    // TODO: add priority header
    // u=2 for interactive (user doing action, e.g., create folder),
    // u=4 for normal (user secondary action, e.g., refresh children listing),
    // u=5 for background (e.g., upload, download)
    // u=7 for optional (e.g., metrics, telemetry)
    private async fetch(
        request: { method: string; url: string; signal?: AbortSignal },
        callback: () => Promise<Response>,
        {
            attempt,
            previousError,
        }: {
            attempt: number;
            previousError?: unknown;
        } = {
            attempt: 0,
        },
    ): Promise<Response> {
        if (request.signal?.aborted) {
            throw new AbortError(c('Error').t`Request aborted`);
        }

        if (attempt > 0) {
            this.logger.debug(`${request.method} ${request.url}: retry ${attempt}`);
        } else {
            this.logger.debug(`${request.method} ${request.url}`);
        }

        if (this.hasReachedServerErrorLimit) {
            this.logger.warn('Server errors limit reached');
            throw new ServerError(c('Error').t`Too many server errors, please try again later`);
        }
        if (this.hasReachedTooManyRequestsErrorLimit) {
            this.logger.warn('Too many requests limit reached');
            throw new RateLimitedError(c('Error').t`Too many server requests, please try again later`);
        }

        const start = Date.now();

        let response;
        try {
            response = await callback();
        } catch (error: unknown) {
            if (error instanceof Error) {
                if (error.name === 'AbortError') {
                    this.logger.debug(`${request.method} ${request.url}: Aborted`);
                    throw new AbortError(c('Error').t`Request aborted`);
                }

                if (error.name === 'OfflineError') {
                    this.offlineErrorHappened();
                    this.logger.info(`${request.method} ${request.url}: Offline error, retrying`);
                    await waitSeconds(OFFLINE_RETRY_DELAY_SECONDS);
                    return this.fetch(request, callback, { attempt: attempt + 1, previousError: error });
                }

                if (error.name === 'TimeoutError' && attempt + 1 < MAX_TIMEOUT_ERROR_RETRY_ATTEMPTS) {
                    this.logger.warn(`${request.method} ${request.url}: Timeout error, retrying`);
                    await waitSeconds(SERVER_ERROR_RETRY_DELAY_SECONDS);
                    return this.fetch(request, callback, { attempt: attempt + 1, previousError: error });
                }

                if (isNetworkError(error) && attempt + 1 < MAX_NETWORK_ERROR_RETRY_ATTEMPTS) {
                    this.logger.warn(`${request.method} ${request.url}: Network error, retrying`);
                    await waitSeconds(NETWORK_ERROR_RETRY_DELAY_SECONDS);
                    return this.fetch(request, callback, { attempt: attempt + 1, previousError: error });
                }
            }
            if (attempt === 0) {
                this.logger.error(`${request.method} ${request.url}: failed, retrying once`, error);
                await waitSeconds(GENERAL_RETRY_DELAY_SECONDS);
                return this.fetch(request, callback, { attempt: attempt + 1, previousError: error });
            }
            this.logger.error(`${request.method} ${request.url}: failed`, error);
            throw error;
        }

        this.clearSubsequentOfflineErrors();

        const end = Date.now();
        const duration = end - start;

        if (response.ok) {
            this.logger.info(`${request.method} ${request.url}: ${response.status} (${duration}ms)`);
        } else {
            this.logger.warn(`${request.method} ${request.url}: ${response.status} (${duration}ms)`);
        }

        if (response.status === HTTPErrorCode.TOO_MANY_REQUESTS) {
            this.tooManyRequestsErrorHappened();
            const timeout = parseInt(response.headers.get('retry-after') || '0', 10) || DEFAULT_429_RETRY_DELAY_SECONDS;
            await waitSeconds(timeout);
            return this.fetch(request, callback, { attempt: attempt + 1, previousError: response.status });
        } else {
            this.clearSubsequentTooManyRequestsError();
        }

        // Automatically re-try 5xx glitches on the server, but only once
        // and report the incident so it can be followed up.
        if (response.status >= 500) {
            this.serverErrorHappened();

            if (attempt > 0) {
                this.logger.warn(`${request.method} ${request.url}: ${response.status} - retry failed`);
            } else {
                await waitSeconds(SERVER_ERROR_RETRY_DELAY_SECONDS);
                return this.fetch(request, callback, { attempt: attempt + 1, previousError: response.status });
            }
        } else {
            if (attempt > 0) {
                const previousErrorMessage =
                    previousError instanceof Error ? previousError.message : String(previousError);
                const isWarning =
                    !(previousError instanceof Error) ||
                    (previousError instanceof Error &&
                        previousError.name !== 'TimeoutError' &&
                        previousError.name !== 'OfflineError' &&
                        !isNetworkError(previousError));

                if (isWarning) {
                    this.telemetry.recordMetric({
                        eventName: 'apiRetrySucceeded',
                        failedAttempts: attempt,
                        url: request.url,
                        previousError,
                    });
                    this.logger.warn(`${request.method} ${request.url}: ${previousErrorMessage} - retry helped`);
                } else {
                    this.logger.debug(`${request.method} ${request.url}: ${previousErrorMessage} - retry helped`);
                }
            }
            this.clearSubsequentServerErrors();
        }

        return response;
    }

    private get hasReachedTooManyRequestsErrorLimit(): boolean {
        const secondsSinceLast429Error = (Date.now() - (this.lastTooManyRequestsErrorAt || Date.now())) / 1000;
        return (
            this.subsequentTooManyRequestsCounter >= TOO_MANY_SUBSEQUENT_429_ERRORS &&
            secondsSinceLast429Error < TOO_MANY_SUBSEQUENT_429_ERRORS_TIMEOUT_IN_SECONDS
        );
    }

    private tooManyRequestsErrorHappened() {
        this.subsequentTooManyRequestsCounter++;
        this.lastTooManyRequestsErrorAt = Date.now();

        // Do not emit event if there is first few 429 errors, only when
        // the client is very limited. This is generic event and it doesn't
        // take into account that various endpoints can be rate limited
        // independently.
        if (this.subsequentTooManyRequestsCounter === TOO_MANY_SUBSEQUENT_429_ERRORS) {
            this.sdkEvents.requestsThrottled();
        }
    }

    private clearSubsequentTooManyRequestsError() {
        if (this.subsequentTooManyRequestsCounter >= TOO_MANY_SUBSEQUENT_429_ERRORS) {
            this.sdkEvents.requestsUnthrottled();
        }

        this.subsequentTooManyRequestsCounter = 0;
        this.lastTooManyRequestsErrorAt = undefined;
    }

    private get hasReachedServerErrorLimit(): boolean {
        const secondsSinceLastServerError = (Date.now() - (this.lastServerErrorAt || Date.now())) / 1000;
        return (
            this.subsequentServerErrorsCounter >= TOO_MANY_SUBSEQUENT_SERVER_ERRORS &&
            secondsSinceLastServerError < TOO_MANY_SUBSEQUENT_SERVER_ERRORS_TIMEOUT_IN_SECONDS
        );
    }

    private serverErrorHappened() {
        this.subsequentServerErrorsCounter++;
        this.lastServerErrorAt = Date.now();
    }

    private clearSubsequentServerErrors() {
        this.subsequentServerErrorsCounter = 0;
        this.lastServerErrorAt = undefined;
    }

    private offlineErrorHappened() {
        this.subsequentOfflineErrorsCounter++;

        if (this.subsequentOfflineErrorsCounter === TOO_MANY_SUBSEQUENT_OFFLINE_ERRORS) {
            this.sdkEvents.transfersPaused();
        }
    }

    private clearSubsequentOfflineErrors() {
        if (this.subsequentOfflineErrorsCounter >= TOO_MANY_SUBSEQUENT_OFFLINE_ERRORS) {
            this.sdkEvents.transfersResumed();
        }

        this.subsequentOfflineErrorsCounter = 0;
    }
}
